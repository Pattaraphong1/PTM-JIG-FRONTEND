import React from "react";
import Navbar from "../../components/Navbar/Navbar";
import Sidebar from "../../components/Sidebar/Sidebar";
import Footer from "../../components/Footer/Footer";
import Swal from "sweetalert2";
import styles from "../MasterEquipment/MasterEquipment.module.css";

import { useState, useEffect, useRef } from "react";

import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
//import { Button } from 'primereact/button';
import { Tooltip } from 'primereact/tooltip';
import { ProductService } from "../../service/ProductService";


import { Dropdown } from 'primereact/dropdown';
               
import {Button} from "react-bootstrap";
import { Form, Row, Col, Modal, Container } from "react-bootstrap";


function MasterEquipment() {

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle form submission logic here
    console.log('Form submitted!');
    handleClose();
  };


     const imageBodyTemplate = (rowData) => {
        return <img src={`https://primefaces.org/cdn/primereact/images/product/${rowData.image}`} alt={rowData.image} className="shadow-2 border-round" style={{ width: '64px' }} />;
    };

  //-----------------------------------------------//
   const [products, setProducts] = useState([]);
    const dt = useRef(null);

    const cols = [
      { field: 'id', header: 'ID' },
      { field: 'code', header: 'Code' },
      { field: 'name', header: 'Name' },
      { field: 'description', header: 'Description' },
      { field: 'image', header: 'Image', body:{imageBodyTemplate}},
      { field: 'price', header: 'Price' },
      { field: 'category', header: 'Category' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'inventoryStatus', header: 'Inventory Status' }
    ];

    const exportColumns = cols.map((col) => ({ title: col.header, dataKey: col.field }));

    useEffect(() => {
        ProductService.getProductsMini().then((data) => setProducts(data));
    }, []); // eslint-disable-line react-hooks/exhaustive-deps

    const exportCSV = (selectionOnly) => {
        dt.current.exportCSV({ selectionOnly });
    };

    const exportPdf = () => {
        import('jspdf').then((jsPDF) => {
            import('jspdf-autotable').then(() => {
                const doc = new jsPDF.default(0, 0);

                doc.autoTable(exportColumns, products);
                doc.save('products.pdf');
            });
        });
    };

    const exportExcel = () => {
        import('xlsx').then((xlsx) => {
            const worksheet = xlsx.utils.json_to_sheet(products);
            const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
            const excelBuffer = xlsx.write(workbook, {
                bookType: 'xlsx',
                type: 'array'
            });

            saveAsExcelFile(excelBuffer, 'products');
        });
    };

    const saveAsExcelFile = (buffer, fileName) => {
        import('file-saver').then((module) => {
            if (module && module.default) {
                let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
                let EXCEL_EXTENSION = '.xlsx';
                const data = new Blob([buffer], {
                    type: EXCEL_TYPE
                });

                module.default.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
            }
        });
    };

    const header = (
        <div className="flex align-items-center justify-content-end gap-2">
            {/* <Button type="button" icon="pi pi-file" rounded onClick={() => exportCSV(false)} data-pr-tooltip="CSV" />
            <Button type="button" icon="pi pi-file-excel" severity="success" rounded onClick={exportExcel} data-pr-tooltip="XLS" />
            <Button type="button" icon="pi pi-file-pdf" severity="warning" rounded onClick={exportPdf} data-pr-tooltip="PDF" /> */}
             <Button icon="fa-solid fa-file-csv" variant="primary" >CSV</Button>
            <Button variant="success">XLSX</Button>
            <Button variant="danger">PDF</Button>
        </div>
    );
  //-----------------------------------------------//
  
  return (
    <>
      <Navbar />
      <Sidebar />
      {/* Content */}
      {/* Content Wrapper. Contains page content */}
      <div className="content-wrapper">
        {/* Content Header (Page header) */}
        <div className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col">
                <h1 className="m-0">Master Equipment</h1>
              </div>
              {/* /.col */}
            </div>           

            {/* /.row */}
          </div>
          {/* /.container-fluid */}
        </div>
        {/* /.content-header */}

        {/* Main content */}
        <section className="content">
          <div className="container-fluid"></div>
          <div className={styles.add_masterEquipt_button}>
            {/* <Button variant="primary" onClick={addEquipment}>ADD Equipment</Button> */}
            <Button variant="primary" onClick={handleShow}>ADD Equipment</Button>
          </div>

          <div className="card">
             <Tooltip target=".export-buttons>button" position="bottom" />

            <DataTable ref={dt} value={products} header={header} tableStyle={{ minWidth: '50rem' }}>
                {cols.map((col, index) => (
                    <Column key={index} field={col.field} header={col.header} />
                ))}
            </DataTable>
          </div>
          {/*/. container-fluid */}
        </section>
        {/* /.content */}
      </div>
      {/* /.content-wrapper */}
      {/* End Content */}


      {/* Modal */}
  
      <Modal show={show} onHide={handleClose} size="xl">
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <Form onSubmit={handleSubmit}>
              <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Code</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Code" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Control No</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Control No" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Jig Name</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Jig Name" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Application Model</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Application Model" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Jig Number</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Jig Number" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Entry Date</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Entry Date" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Marker</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Marker" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Issue Date</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="date" placeholder="Enter Issue Date" />
              </Col>
            </Row>
             <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Suffix No</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Suffix No" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Calibration Date</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="date" placeholder="Enter Calibration Date" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Serial No</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Serial No" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Next Calibration Date</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="date" placeholder="Enter Calibration Date" />
                
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Asset No</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Asset No" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Shelf</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Shelf" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Type</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Type" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Floor</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Floor" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Photo</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="file" placeholder="Enter Photo" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Location</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Location" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Respond</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 2: Input for Code */}
                <Form.Control type="text" placeholder="Enter Respond" />
              </Col>
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Calibration Control</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Calibration Control" />
              </Col>
            </Row>
            <Row className="mb-3">
              <Col xs={12} md={6} lg={2}> {/* Column 1: Label "Code" */}
                <Form.Label className="col-form-label text-md-end text-start">Section</Form.Label>
              </Col>
               <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Section" />
              </Col>
             
              <Col xs={12} md={6} lg={2}> {/* Column 3: Label "Control No" */}
                <Form.Label className="col-form-label text-md-end text-start">Remark</Form.Label>
              </Col>
              <Col xs={12} md={6} lg={4}> {/* Column 4: Input for Control No */}
                <Form.Control type="text" placeholder="Enter Remark" />
              </Col>
            </Row>
            </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
      {/* Close Modal */}

      
      <Footer />
    </>
  );
}

export default MasterEquipment;
