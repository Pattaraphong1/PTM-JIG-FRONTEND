import React, { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { ProductService } from '../../service/ProductService';
import {CustomerService} from '../../service/CustomerService';
import { Toolbar } from 'primereact/toolbar'; // Import Toolbar
import axios from "axios";
// Import Font Awesome Icons
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFileExcel, faFilePdf, faPrint } from '@fortawesome/free-solid-svg-icons'; // ตัวอย่างไอคอนที่ใช้
 


export default function DataTable_Exam() {
    const [customers, setCustomers] = useState([]);
    const [products, setProducts] = useState(null);

    useEffect(() => {
        CustomerService.getCustomersMedium().then((data) => setCustomers(data));
    }, []);

    // Export Excel
    const exportExcel = () => {
        import('xlsx').then((xlsx) => {
            const worksheet = xlsx.utils.json_to_sheet(products);
            const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
            const excelBuffer = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
            saveAsExcelFile(excelBuffer, 'products');
        });
    };

    const saveAsExcelFile = (buffer, fileName) => {
        import('file-saver').then((module) => {
            if (module && module.default) {
                let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
                let EXCEL_EXTENSION = '.xlsx';
                const data = new Blob([buffer], {
                    type: EXCEL_TYPE
                });
                module.default.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
            }
        });
    };

    // Export PDF
    const exportPdf = () => {
        const doc = new jsPDF();
        const headers = [['Code', 'Name', 'Status', 'Price']];
        const data = products.map(product => [product.code, product.name, product.inventoryStatus, new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(product.price)]);

        autoTable(doc, {
            head: headers,
            body: data,
        });
        doc.save('products.pdf');
    };

    // Print
    const printTable = () => {
        const printContents = dt.current.getTable().outerHTML;
        const originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    };

     const rightToolbarTemplate = () => {
        return (
          <div className="row">
               <div className="flex flex-wrap-content  gap-2">
                {/* <Button label="XLSX" icon="pi pi-file-excel" severity="success" onClick={exportExcel} />
                <Button label="PDF" icon="pi pi-file-pdf" severity="danger" onClick={exportPdf} />
                <Button label="Print" icon="pi pi-print" severity="info" onClick={printTable} /> */}
              <div>
                  <button type="button" className="btn btn-primary mr-2"  onClick={exportExcel}><FontAwesomeIcon icon={faFileExcel} className="me-2" />XLSX</button>
                  <button type="button" className="btn btn-danger mr-2" onClick={exportPdf}><FontAwesomeIcon icon={faFilePdf} className="me-2"/>PDF</button>
                  <button type="button" className="btn btn-info" onClick={printTable}><FontAwesomeIcon icon={faPrint} className="me-2"/>Print</button>
              </div>

            </div>
          </div>
           
        );
    };

        const statusBodyTemplate = (rowData) => {
        return <Tag value={rowData.inventoryStatus} severity={getSeverity(rowData.inventoryStatus)}></Tag>;
    };

     const priceBodyTemplate = (rowData) => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(rowData.price);
    };

    const allowEdit = (rowData) => {
        return rowData.name !== 'Blue Band';
    };

  async function fetchEquipment() {
  try {
    const response = await axios.get('http://localhost:3000/api/allMasterEquipment');
    return response.data; // ข้อมูลจะอยู่ใน response.data
  } catch (error) {
    console.error('เกิดข้อผิดพลาดในการดึงข้อมูล:', error);
    return null;
  }
}

// ตัวอย่างการเรียกใช้ฟังก์ชัน
fetchEquipment().then(data => {
  if (data) {
    console.log('ข้อมูลที่ได้:', data);
    // คุณสามารถนำข้อมูลนี้ไปใช้ในขั้นตอนต่อไปได้เลยค่ะ
  }
});

    return (
        <div className="card">
           <Toolbar className="mb-4" right={rightToolbarTemplate}></Toolbar>
            <DataTable value={customers} paginator rows={5} rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '50rem' }}>
                <Column field="name" header="Name" style={{ width: '25%' }}></Column>
                <Column field="country.name" header="Country" style={{ width: '25%' }}></Column>
                <Column field="company" header="Company" style={{ width: '25%' }}></Column>
                <Column field="representative.name" header="Representative" style={{ width: '25%' }}></Column>
            </DataTable>
        </div>
    );
}
        